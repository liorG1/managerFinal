import { Box, Input } from '@chakra-ui/react'

import {
    FormControl,
    FormLabel,
    FormErrorMessage,
    FormHelperText,
  } from '@chakra-ui/react'
import axios from 'axios'
import { useState } from 'react'
import { Link } from 'react-router-dom'
  

export default function Login(){
    const [userDetails,setDetails]=useState({
        name:'',
        email:'',
        password:''
    })

    const [success,setSuccess]=useState(null)
    const [err,setError]=useState(null)
    const addDetail=(e)=>{
        console.log(e.target.name);
        setDetails({...userDetails,[e.target.name]:e.target.value})
        console.log(userDetails);
    }

    const submit= async(e)=>{
        e.preventDefault();
        try {
            const response=await axios.post(
                "http://localhost:3000/users/login",
                userDetails,
                {
                   headers :{"Content-Type":"application/json"},
                }
            )
            console.log(response);
            if( response.data.success){
                setSuccess(true)
            location.href='http://localhost:5173/user'
            }
            else{
                setSuccess(false)
                setError(response.data.err)
            }
        } catch (error) {
            console.log(error);
            setSuccess(false)
            setError(error.response.data.err)
        }
        }
    return(
        <Box as={"form"}>
            <div style={{color:"red",fontSize:"2em"}}>Login page</div>
        <FormControl id='name' >
        <FormLabel htmlFor='name' required>full name</FormLabel>
        <Input name='name' required type='text' onChange={addDetail} />
        </FormControl>

        <FormControl id='email' >
        <FormLabel htmlFor='email' required> email</FormLabel>
        <Input name='email' required type='email' onChange={addDetail} />
        </FormControl>

        <FormControl id='password' >
        <FormLabel htmlFor='password' required>password</FormLabel>
        <Input name='password' required type='password' onChange={addDetail} />
        </FormControl>

        <button type='submit' onClick={submit} >click to submit</button>

        {success&&<div>wellcome {userDetails.name}</div>}
        {success==false&&<div>login falild error: {err}</div>}
      {/*   {success&&<Link to={'http://localhost:5173/allProducts'}></Link>} */}
        </Box>
    )
}

