import {Box, FormControl,FormLabel,Input } from "@chakra-ui/react";
import axios from "axios";
import { useState } from "react";


export default function AddProduct(){
    const [success,setSuccess]=useState(null)
    const [product,setProduct]=useState({
    img:'',
    catagory:'',
    price:'',
    description:'',
    brand:'',
    name:''
    })
    const ProductHandler=(e)=>{
e.preventDefault()
if (e.target.name!='catagory'){

    setProduct({...product,[e.target.name]:e.target.value})
}
else {
    setProduct({...product,[e.target.name]:e.target.value.split(',')})
}
console.log(product);
    }

    const post=async ()=>{
        const response=await axios.post(
           'http://localhost:3000/products/add',
           product,
           {
            headers:{
               'Content-Type':'application/json'
            }
           }
        )
        console.log(response);
    }
    return(
        <Box as='form'>
<span  >add product</span>
<FormControl id="name">
<FormLabel id='name'>product name</FormLabel>
    <Input name="name" onChange={ProductHandler}></Input>
</FormControl>

<FormControl id="brand">
<FormLabel id='brand'>product brand</FormLabel>
    <Input name="brand" onChange={ProductHandler}></Input>
</FormControl>

<FormControl id="description">
<FormLabel id='description'>product description</FormLabel>
    <Input name="description" onChange={ProductHandler}></Input>
</FormControl>

<FormControl id="img">
<FormLabel id='img'>product img</FormLabel>
    <Input name="img" onChange={ProductHandler}></Input>
</FormControl>

<FormControl id="price">
<FormLabel id='price'>product price</FormLabel>
    <Input name="price" onChange={ProductHandler}></Input>
</FormControl>

<FormControl id="catagory">
<FormLabel id='catagory'>product catagory</FormLabel>
    <Input name="catagory" onChange={ProductHandler}></Input>
</FormControl>

<button type="submit" onClick={post}>add</button>
        </Box>
    )
}